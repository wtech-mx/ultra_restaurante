<div class="table-responsive">
<table class="table table-bordered table-striped" id="sr_sales_report">
    <thead>
        <tr>
            <th>@lang('messages.date')</th>
            <th>@lang('sale.invoice_no')</th>
            <th>@lang('sale.customer_name')</th>
            <th>@lang('sale.location')</th>
            <th>@lang('sale.payment_status')</th>
            <th>@lang('sale.total_amount')</th>
            <th>@lang('sale.total_paid')</th>
            <th>@lang('sale.total_remaining')</th>
        </tr>
    </thead>
</table>
</div>